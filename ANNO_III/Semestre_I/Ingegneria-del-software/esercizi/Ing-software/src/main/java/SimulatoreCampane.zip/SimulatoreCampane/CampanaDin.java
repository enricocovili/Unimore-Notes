package SimulatoreCampane;

public class CampanaDin extends Campana{
    public CampanaDin() {
        this.suono = "din";
    }
}
