package SimulatoreCampane;

public class CampanaDon extends Campana{
    public CampanaDon() {
        this.suono = "don";
    }
}
