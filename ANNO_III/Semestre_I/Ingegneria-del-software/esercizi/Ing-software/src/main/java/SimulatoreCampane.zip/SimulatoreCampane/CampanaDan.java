package SimulatoreCampane;

public class CampanaDan extends Campana{
    public CampanaDan() {
        this.suono = "dan";
    }
}
