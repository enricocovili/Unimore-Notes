#define VAL 123
#ifdef VAL
int x = VAL;
#endif
x++;