#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct product {
  int res;
  int p1, p2;
};

extern int prodotto_altri_due(const int *v, size_t n) {
  if (n == 0 || v == NULL) return -1;
  size_t prod_totali = 0;
  for (int i = n - 1; i > 0; i--) {
    prod_totali += i;
  }
  struct product *products = calloc(prod_totali, sizeof(struct product));
  int c = 0;
  for (int i = 0; i < n; i++) {
    for (int j = i + 1; j < n; j++) {
      products[c].res = v[i] * v[j];
      products[c].p1 = i;
      products[c].p2 = j;
      c++;
    }
  }
  int res = 0;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < prod_totali; j++) {
      if (products[j].res == v[i] && products[j].p1 != i &&
          products[j].p2 != i) {
        res++;
        break;
      }
    }
  }
  free(products);
  return res;
}

int main(int argc, char **argv) {
  int arr[] = {10, 2, 8, 4, 1, 1, 6, 8, 3, 7, 3, 9, 7, 4, 8,
               5,  1, 3, 5, 3, 8, 4, 8, 9, 4, 2, 6, 3, 7, 10};
  int test = prodotto_altri_due(arr, 30);
  return 0;
}