#pragma once

extern char *sostituisci(const char *str, const char *vecchia,
                         const char *nuova);