#pragma once

#include <stdlib.h>

struct matrix {
  size_t rows, cols;
  double *data;
};

extern void mat_symdecomp(const struct matrix *m, struct matrix *S,
                          struct matrix *A);

extern struct matrix *mat_replicate(const struct matrix *m);