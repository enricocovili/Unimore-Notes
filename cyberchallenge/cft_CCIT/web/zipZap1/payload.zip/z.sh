/getflag > f.txt
